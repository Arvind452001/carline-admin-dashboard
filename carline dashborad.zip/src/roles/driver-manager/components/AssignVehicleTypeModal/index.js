export { default } from './AssignVehicleTypeModal'
