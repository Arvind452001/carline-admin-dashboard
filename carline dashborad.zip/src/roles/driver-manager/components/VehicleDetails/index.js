export { default } from './VehicleDetails'
