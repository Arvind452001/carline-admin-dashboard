export { default } from './TripDetails'
