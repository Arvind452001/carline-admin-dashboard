export { default } from './CompletedTrips'
