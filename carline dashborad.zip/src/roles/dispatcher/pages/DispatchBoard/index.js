export { default } from './DispatchBoard'
