export { default } from './InvoiceTable'
