export { default } from './PaymentTable'
