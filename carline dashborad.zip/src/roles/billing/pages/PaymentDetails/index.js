export { default } from './PaymentDetails'
