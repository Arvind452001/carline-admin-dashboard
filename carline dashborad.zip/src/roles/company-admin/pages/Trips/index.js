export { default } from './Trips'
