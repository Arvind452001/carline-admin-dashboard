export { default } from './Company'
