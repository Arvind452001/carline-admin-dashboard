export { default } from './Areas'
