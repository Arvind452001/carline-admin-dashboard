export { default } from './IVR'
