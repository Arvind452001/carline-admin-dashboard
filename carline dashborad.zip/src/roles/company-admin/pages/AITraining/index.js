export { default } from './AITraining'
