export { default } from './CustomerTable'
