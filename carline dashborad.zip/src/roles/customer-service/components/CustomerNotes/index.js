export { default } from './CustomerNotes'
