export { default } from './CustomerProfile'
