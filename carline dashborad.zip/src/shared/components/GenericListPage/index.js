export { default } from './GenericListPage'
